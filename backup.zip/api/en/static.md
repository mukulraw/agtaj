## 静态页面

<a name="index" />
### 静态页面相关信息

**_地址_**

* `域名+/media/mobile/private.html` - 法律-隐私声明
* `域名+/media/mobile/clause.html` - 法律-条款
* `域名+/media/mobile/ayuda.html` - 帮助信息

---------------------------------------