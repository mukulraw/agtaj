## 其他

<a name="getFormKey" />
### 获取页面form_key


**`GET` `/mobileapi/checkout/getFormKey`**

获取页面form_key，需要带`cookies`.

**_Paramers_**

* `null` 

**_Form_**

* `null` 

**_Examples_**

```js
/mobileapi/checkout/getFormKey
```

**_Response_**

```js
{
	code: 0, 
	msg: "get form key success!",
	model: "q71ubHrdUdfVTxje" //form key 的值
}
```

---------------------------------------


